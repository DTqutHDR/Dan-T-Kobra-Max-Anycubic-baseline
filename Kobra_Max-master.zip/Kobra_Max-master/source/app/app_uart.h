#ifndef __APP_UART_H__
#define __APP_UART_H__


#include "hc32_ddl.h"





#endif
