#ifndef __BSP_WDT_H__
#define __BSP_WDT_H__


#include "hc32_ddl.h"


void bsp_wdt_init(void);
void bsp_wdt_refresh(void);


#endif

