#### Hc32f460kct6 Marlin
HDSC package here:
https://github.com/ANYCUBIC-3D/HDSC_SupportPackage
